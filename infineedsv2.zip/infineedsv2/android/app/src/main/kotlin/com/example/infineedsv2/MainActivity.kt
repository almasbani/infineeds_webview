package com.example.infineedsv2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
